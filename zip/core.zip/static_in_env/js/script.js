$(function(){

	// toggle navbar
    $('#__navbar-toggleJS').click(function(){
       $(this).next('.__nav').toggleClass('toggle');
    })

})